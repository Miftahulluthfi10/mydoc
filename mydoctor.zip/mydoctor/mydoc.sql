-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Jun 2021 pada 15.22
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydoc`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tanggal vaksin`
--

CREATE TABLE `tanggal vaksin` (
  `id_tgl` int(3) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tgl_vaks1` date NOT NULL,
  `tgl_vaks2` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tanggal vaksin`
--

INSERT INTO `tanggal vaksin` (`id_tgl`, `id_user`, `tgl_vaks1`, `tgl_vaks2`) VALUES
(1, 2, '2021-08-01', '2021-08-15'),
(2, 6, '2021-08-01', '2021-08-15'),
(3, 2, '2021-08-01', '2021-08-15'),
(4, 2, '2021-08-01', '2021-08-15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(8) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(125) NOT NULL,
  `image` varchar(500) NOT NULL,
  `jenkel` varchar(20) NOT NULL,
  `no_tel` varchar(15) NOT NULL,
  `role` char(10) NOT NULL,
  `id_vaks` int(3) NOT NULL,
  `nim` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama`, `kelas`, `alamat`, `password`, `email`, `image`, `jenkel`, `no_tel`, `role`, `id_vaks`, `nim`) VALUES
(2, 'Devita Anindya Putri', '12.3B', 'Besoli, Pracimantoro, Wonogiri, Jawa Tengah', 'devdev', 'devita@gmail.com', 'dewik4.jpg', 'Wanita', '0836489472625', 'Mahasiswa', 0, 12190828),
(12, 'Anastasya Meyliana S.Kom', '', 'Jl. Bayangkara Wates', 'asuanas', 'anas@gmail.com', 'dosen.img', 'Wanita', '0830303030', 'Dosen', 0, 98757543);

-- --------------------------------------------------------

--
-- Struktur dari tabel `vaksin`
--

CREATE TABLE `vaksin` (
  `id_vaks` int(3) NOT NULL,
  `vaksin` char(50) NOT NULL,
  `ket` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tanggal vaksin`
--
ALTER TABLE `tanggal vaksin`
  ADD PRIMARY KEY (`id_tgl`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_vaks` (`id_vaks`);

--
-- Indeks untuk tabel `vaksin`
--
ALTER TABLE `vaksin`
  ADD PRIMARY KEY (`id_vaks`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tanggal vaksin`
--
ALTER TABLE `tanggal vaksin`
  MODIFY `id_tgl` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `vaksin`
--
ALTER TABLE `vaksin`
  MODIFY `id_vaks` int(3) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
