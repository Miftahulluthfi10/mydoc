<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function index()
    {
        $this->load->view('login');
    }

    public function dashboard()
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('template/header', $data);
        $this->load->view('dashboard', $data);
        $this->load->view('template/footer', $data);
    }
    public function teledoctor()
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('template/header', $data);
        $this->load->view('teledoctor', $data);
        $this->load->view('template/footer', $data);
    }
    public function registrasi()
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('template/header', $data);
        $this->load->view('registrasi', $data);
        $this->load->view('template/footer', $data);
    }
    public function info_penting()
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('template/header', $data);
        $this->load->view('info-penting', $data);
        $this->load->view('template/footer', $data);
    }
    public function statistik()
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('template/header', $data);
        $this->load->view('statistik', $data);
        $this->load->view('template/footer', $data);
    }
    public function akun()
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('template/header', $data);
        $this->load->view('akun', $data);
        $this->load->view('template/footer', $data);
    }
    public function logout()
    {
        $this->session->sess_destroy();
        redirect('home/index');
    }
    public function cek_vaksin()
    {
        $nama = htmlspecialchars($this->input->post('nama', true));
        $nim = htmlspecialchars($this->input->post('nim', true));
        $user = $this->m_user->cekData(['nama' => $nama])->row_array();

        //cek user
        if ($user) {
            if ($nim == $user['nim']) {
                $data = [
                    'nama' => $user['nama'],
                    'status' => "Anda Telah Terdaftar"
                ];
                $this->session->set_flashdata('pesan', '<div class="card">
                <span class="nama">Anda Telah Terdaftar</span>
                <a href="" class="close">×</a>
            </div>');
                redirect('home/dashboard');
            } else {
                $this->session->set_flashdata('pesan', '<div class="card">
                <span class="nama">Mohon Maaf Anda Belum Terdaftar</span>
                <a href="" class="close">×</a>
            </div>');
                redirect('home/dashboard');
            }
        } else {
            $this->session->set_flashdata('pesan', '<div class="card">
            <span class="nama">Mohon Maaf Anda Belum Terdaftar</span>
            <a href="" class="close">×</a>
        </div>');
            redirect('home/dashboard');
        }
    }
}
