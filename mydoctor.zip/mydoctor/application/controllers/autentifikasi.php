<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Autentifikasi extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function aute_login()
    {
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email', [
            'required' => 'Email Harus Diisi',
            'valid_email' => 'Email tidak valid',
        ]);
        $this->form_validation->set_rules('password', 'Password', 'trim|required', [
            'required' => 'Password Harus Diisi',
        ]);
        if ($this->form_validation->run() === false) {
            $data['judul'] = 'Login';
            $data['user'] = '';

            $this->load->view('login', $data);
        } else {
            $this->login_mahasiswa();
        }
    }
    public function login_mahasiswa()
    {
        $email = htmlspecialchars($this->input->post('email', true));
        $password = htmlspecialchars($this->input->post('password', true));
        $user = $this->m_user->cekData(['email' => $email])->row_array();

        //cek user
        if ($user) {
            if ($password == $user['password']) {
                $data = [
                    'email' => $user['email'],
                    'status' => "login"
                ];
                $this->session->set_userdata($data);
                redirect('home/dashboard');
            } else {
                $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Password salah!!</div>');
                redirect('home/index');
            }
        } else {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Email tidak terdaftar!!</div>');
            redirect('home/index');
        }
    }
}
