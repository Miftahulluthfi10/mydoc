<div class="content">
    <div class="box-registrasi">
        <h2>DATA VAKSINASI COVID-19!</h2>
    </div>

    <div class="conten-bottom">

    </div>
</div>