<div class="content">
    <div class="box-registrasi">
        <h2>INFO PENTING!</h2>
        <p>Data ini diharapkan dapat memberikan informasi kepada mahasiswa dan dosen. Disamping itu angka persebaran ini harapan kami dapat dijadikan kewaspadaan kita. Tetapi ini tidak menunjukkan zona merah. Karena secara epidemiologis wilayah DIY ini adalah wilayah yang padat, tidak terpisahkan, sehingga jangan dimaknai bahwa hanya kecamatan yang ada kasus yang perlu diwaspadai</p>
    </div>

    <div class="conten-bottom">

        <div class="table-left">
            <table border="1px solid black" style="width: 100%;">
                <tr>
                    <th colspan="3">Total Konfirmasi</th>
                </tr>
                <tr>
                    <th colspan="3">38703</th>
                </tr>
                <tr>
                    <td>Dirawat <br>
                        <p>4119 (+184)</p>
                    </td>
                    <td>
                        Meninggal<br>
                        <p> 948 (+5)</p>
                    </td>
                    <td>
                        Sembuh <br>
                        <p>33636 (+212)</p>
                    </td>
                </tr>
                <tr>
                    <td>10.64 %(45.89%)</td>
                    <td>2.45 %(1.25%)</td>
                    <td>86.91 %(52.87%)</td>
                </tr>
            </table>
        </div>
        <div class="table-right">
            <table border="1px solid black">
                <tr>
                    <th>Total Suspek</th>
                </tr>
                <tr>
                    <th>38.651</th>
                </tr>
            </table>
        </div>
    </div>
</div>