<div class="content">
    <div class="box-teledoc">

        <h3><img class="icon-logo" src="<?= base_url(); ?>assets/image/icon/teledoc.png" alt="">Teledokter</h3>
        <h2>Hentikan penyeberan COVID-19 sekarang !</h2>
        <p>Periksa dini dan konsultasikan kesehatanmu <br> secara mandiri dan secara online!</p>
        <img width="400px" class="img-docters" src="<?= base_url(); ?>/assets/image/dokter.png" alt="">
    </div>

    <div class="conten-bottom">
        <div>
            <h2>Periksa Kesehatan Mandiri</h2>
            <a href="https://covid19.prixa.ai/"><img class="sponsor-img" src="<?= base_url(); ?>/assets/image/PRIXA.png" alt=""></a>
            <a href="https://www.prosehat.com/"><img class="sponsor-img" src="<?= base_url(); ?>/assets/image/BPTT.png" alt=""></a>
            <a href="https://www.gooddoctor.co.id/produk-kami/gooddoctor/"><img class="sponsor-img spesial-img" src="<?= base_url(); ?>/assets/image/god.png" alt=""></a>
        </div>
        <div>
            <h2>Konsultasi Dengan Dokter Spesialis</h2>
            <a href="https://www.halodoc.com/"><img class="sponsor-img" src="<?= base_url(); ?>/assets/image/HALODOC.png" alt=""></a>
            <a href="https://www.prosehat.com/"><img class="sponsor-img" src="<?= base_url(); ?>/assets/image/PROSEHAT.png" alt=""></a>
            <a href="https://telkomedika.co.id/"><img class="sponsor-img" src="<?= base_url(); ?>/assets/image/TELKO MEDIKA.png" alt=""></a>
            <a href="https://www.gooddoctor.co.id/produk-kami/gooddoctor/"><img class="sponsor-img spesial-img" src="<?= base_url(); ?>/assets/image/god.png" alt=""></a>

        </div>
    </div>
</div>