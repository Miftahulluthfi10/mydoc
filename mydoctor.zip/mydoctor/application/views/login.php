<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOG-IN</title>
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="<?php echo base_url() ?>assets/css/login.css" rel="stylesheet" type="text/css">

</head>

<body>

    <div id="hero">
        <div class="container">
            <div class="info">
                <div class="kotak">
                    <form action="<?php echo base_url('autentifikasi/aute_login') ?>" method="post">
                        <h1>Hello !</h1>
                        <h3>Sign into your account</h3>
                        <input type="text" name="email" placeholder="Email">
                        <input type="password" name="password" placeholder="Password">
                        <button type="submit">SIGN IN</button>
                    </form>
                    <a class="btn btn-sm btn-danger" href="">Dont't have an account? <i>Create</i></a>
                </div>
            </div>
        </div>
        <div class="sidebar">

            <div class="icon-logo">
                <img src="<?= base_url(); ?>assets/image/LOGO LOGIN.png" width="400px">
            </div>
        </div>
    </div>

</body>

</html>