<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link href="<?php echo base_url() ?>assets/css/doktor.css" rel="stylesheet" type="text/css">
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://use.fontawesome.com/fe136465dc.js"></script>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <img width="250px" src="<?= base_url(); ?>/assets/image/kelompok logo SAMPING.png" class="logo">

            <ul>
                <li>
                    <a class="top-icon" href="<?= base_url('home/dashboard') ?>"><img class="icon-logo" src="<?= base_url(); ?>assets/image/icon/dashboard.png" alt="">Dashboard</a>
                </li>
                <li>
                    <a class="top-icon" href="<?= base_url('home/statistik') ?>"><img class="icon-logo" src="<?= base_url(); ?>assets/image/icon/statistik.png" alt="">Statistik</a>
                </li>
                <li>
                    <a class="top-icon" href="<?= base_url('home/teledoctor') ?>"><img class="icon-logo" src="<?= base_url(); ?>assets/image/icon/teledoc.png" alt="">Teledoc</a>
                </li>
                <li>
                    <a class="top-icon" href="<?= base_url('home/info_penting') ?>"><img class="icon-logo" src="<?= base_url(); ?>assets/image/icon/info.png" alt="">Info Penting</a>
                </li>
                <li>
                    <a class="top-icon" href="<?= base_url('home/registrasi') ?>"><img class="icon-logo" src="<?= base_url(); ?>assets/image/icon/regitrasi vaksin.png" alt="">Registrasi Vaksin</a>
                </li>
                <li>
                    <a style="margin-left: 20px;" class="top-icon" href="<?= base_url('home/akun') ?>"> <img class="detail-akun" src="<?= base_url() . "assets/image/akun/" . $user['image']; ?>" width=" 20px">Akun</a>
                </li>
            </ul>
        </div>