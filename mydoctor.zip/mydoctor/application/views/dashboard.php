<div class="content">
    <div class="box-kotak">
        <?= $this->session->flashdata('pesan'); ?>
        <div class="dashboard-sidebar">
            <p>Lindungi diri dan sekitar dengan </p>
            <p> berpartisipasi dalam program </p>
            <p> vaksinasi COVID-19</p>
            <a class="btn-vaksin" href="">LIHAT JADWAL VAKSINASI <i class="fa fa-arrow-circle-right"></i></a>
        </div>
        <div class="dashboard-sidebar">
            <img class="img-dokter" src="<?= base_url(); ?>/assets/image/okey.png" alt="">
        </div>
    </div>
    <div class="cek-status">
        <h3>Periksa Status Anda Dalam Program Vaksinasi COVID-19</h3>
        <form action="<?php echo base_url('home/cek_vaksin') ?>" method="post">
            <div class="form-group">
                <label for="">Nama Lengkap</label><br>
                <input class="warna" type="text" name="nama" id="" placeholder="Tulis nama lengkap anda disini">
            </div>
            <div class="form-group">
                <label for="">NIM / NIK</label><br>
                <input class="warna" type="text" name="nim" id="" placeholder="Masukkan NIM/NIK">
            </div>
            <button class="btn-submit">Periksa <i style="float: right;" class="fa fa-search"></i></button>
        </form>
    </div>

    <div class="txt-cov">
        <h4>Vaksinasi Covid 19</h4><br>
        <p>Pelaksanaan vaksinasi COVID-19 bertujuan untuk memutus rantai penularan penyakit dan menghentikan
            wabah COVID-19. Vaksin COVID-19 bermanfaat untuk memberi perlindungan tubuh agar tidak jatuh sakit
            akibat COVID-19 dengan cara menimbulkan atau menstimulasi kekebalan spesifik dalam tubuh dengan
            pemberian vaksin. <br><br>

            Pelayanan vaksinasi COVID-19 dilakukan oleh dokter, perawat atau bidan yang memiliki kompetensi dan
            dilaksanakan di Fasilitas Pelayanan Kesehatan milik Pemerintah Pusat, Pemerintah Daerah Provinsi,
            Pemerintah Daerah Kabupaten/Kota atau milik masyarakat/swasta yang memenuhi persyaratan yang
            sudah ditentukan oleh Kementerian Kesehatan Indonesia.</p>
    </div>
</div>

</div>
</div>

<script>
    const container = document.querySelector('.box-kotak');


    container.addEventListener('click', function(e) {
        if (e.target.className == 'close') {
            e.preventDefault();
            e.target.parentElement.style.display = 'none';
        }
    });
</script>