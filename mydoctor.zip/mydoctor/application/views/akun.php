<div class="conten">
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>

    <div class="wrapper">
        <div class="left">
            <img src="<?= base_url() . "assets/image/akun/" . $user['image']; ?>" alt="user" width="200px">
            <h4><?= $user['nama']; ?></h4>
            <p>Mahasiswa</p>
        </div>
        <div class="right">
            <div class="info">
                <h3>Information</h3>
                <div class="info_data">
                    <div class="data">
                        <h4>Email</h4>
                        <p><?= $user['email']; ?></p>
                    </div>
                    <div class="data">
                        <h4>No Telephone</h4>
                        <p><?= $user['no_tel']; ?></p>
                    </div>
                </div>
                <div class="info_data">
                    <div class="data">
                        <h4>Kelas</h4>
                        <p><?= $user['kelas']; ?></p>
                    </div>
                    <div class="data">
                        <h4>Alamat</h4>
                        <p><?= $user['alamat']; ?></p>
                    </div>
                </div>
                <div class="info_data">
                    <div class="data">
                        <h4>Jenis Kelamin</h4>
                        <p><?= $user['jenkel']; ?></p>
                    </div>
                </div>

            </div>

            <div class="projects">
                <h3>Vaksinasi</h3>
                <div class="projects_data">
                    <div class="data">
                        <h4>Jadwal Vaksinasi</h4>
                        <p><b>Rabu, 28 Aapril 2021</b></p>
                        <p>09.00 - 10.00 WIB</p>
                        <p>Kampus UBSI Yogyakarta</p>
                    </div>
                    <div class="data">
                        <h4>Pre-screening</h4>
                        <p>Belum Melakukan Pre-screening</p>
                    </div>
                </div>
            </div>

            <div class="social_media">
                <ul>
                    <li><a href="<?= base_url('home/logout'); ?>"><i class="fas fa-sign-out-alt"></i>LOG OUT</a></li>
                    <!-- <li><a href="#"><i class="fab fa-twitter"></i></a></li> -->
                    <!-- <li><a href="#"><i class="fab fa-instagram"></i></a></li> -->
                </ul>
            </div>
        </div>
    </div>
</div>