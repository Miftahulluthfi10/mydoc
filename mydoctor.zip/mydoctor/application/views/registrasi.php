<div class="content">
    <div class="box-registrasi">
        <img width="90px" src="<?= base_url(); ?>/assets/image/logo-universitas-bina-sarana-informatika-ubsi (1).png" alt="">
        <h2>Registrasi Vaksinasi Coxid-19 Kampus UBSI Yogyakarta</h2>
    </div>

    <div class="cek-registrasi">
        <form <form action="<?php echo base_url('home/cek_vaksin') ?>" method="post">
            <div class="form-group">
                <label for="">Nama Lengkap</label><br>
                <input class="warna" type="text" name="nama" id="" placeholder="Tulis nama lengkap anda disini">
            </div>
            <div class="form-group">
                <label for="">NIM / NIK</label><br>
                <input class="warna" type="text" name="nim" id="" placeholder="Masukkan NIM/NIK">
            </div>
            <button class="btn-submit">Periksa <i style="float: right;" class="fa fa-search"></i></button>
        </form>
    </div>

    <div class="conten-bottom">
        <div>
            <p>Ayo berpartisipasi dalam program vaksinasi COVID-19 ini untuk melindungi anda dan keliarga anda dari COVID-19. Jalankan 3M, menggunakan masker, menjaga jarak, dan mencuci tangan untuk kebaikan kita semua.
                <br>
                <br>
                Informasi lebih lanjut mengenai vaksinasi COVID-19 di Indonesia dapat diakses pada laman https://covid19.go.id/vaksin-covid19, atau melalui tautan berikut FAQ COVID
            </p>
        </div>
    </div>
</div>