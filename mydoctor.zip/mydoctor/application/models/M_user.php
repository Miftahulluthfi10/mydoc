<?php
class M_user extends CI_Model
{

    public function tampil_data()
    {
        return $this->db->get('user');
    }
    public function cekData($where = null)
    {
        return $this->db->get_where('user', $where);
    }
}
